# ga_core.py
import random
import numpy as np
from config import fitness_function, X_MIN, X_MAX # Importa la función y rangos
from utils import decode_chromosome, bits_to_int, int_to_bits, calculate_actual_delta_x

class Individual:
    def __init__(self, num_bits, chromosome=None):
        self.num_bits = num_bits
        if chromosome:
            self.chromosome = list(chromosome) # Asegura que sea una lista de ints
        else:
            self.chromosome = [random.randint(0, 1) for _ in range(self.num_bits)]
        
        self.x_value = None
        self.fitness = None
        self._decode_and_evaluate()

    def _decode_and_evaluate(self):
        self.x_value = decode_chromosome(self.chromosome, X_MIN, X_MAX)
        self.fitness = fitness_function(self.x_value)

    def __repr__(self):
        return (f"Ind(bits={''.join(map(str,self.chromosome))}, "
                f"x={self.x_value:.4f}, fitness={self.fitness:.4f})")

class GeneticAlgorithm:
    def __init__(self, population_size, num_bits, p_mutation_individual, 
                 p_mutation_gene, p_crossover, generations,
                 selection_strategy, crossover_strategy, mutation_strategy, pruning_strategy,
                 maximization=True, max_population_size=None):
        
        self.population_size = population_size
        self.num_bits = num_bits
        self.p_mutation_individual = p_mutation_individual
        self.p_mutation_gene = p_mutation_gene
        self.p_crossover = p_crossover
        self.generations = generations
        self.maximization = maximization
        self.max_population_size = max_population_size if max_population_size else population_size * 2 # Ejemplo

        # Estrategias (serán funciones pasadas como argumento)
        self.selection_strategy = selection_strategy
        self.crossover_strategy = crossover_strategy
        self.mutation_strategy = mutation_strategy
        self.pruning_strategy = pruning_strategy # Para reemplazo/elitismo

        self.population = []
        self.best_individual_history = [] # Para la gráfica de evolución
        self.avg_fitness_history = []
        self.worst_individual_history = [] # Opcional, para gráfica

    def _initialize_population(self):
        self.population = [Individual(self.num_bits) for _ in range(self.population_size)]
        self._evaluate_population()

    def _evaluate_population(self):
        for ind in self.population:
            # La evaluación ya se hace en el init de Individual, pero si el cromosoma cambia:
            ind._decode_and_evaluate() 
        
        # Ordenar la población facilita obtener el mejor/peor
        self.population.sort(key=lambda ind: ind.fitness, reverse=self.maximization)

    def _get_best_individual(self):
        if not self.population:
            return None
        # Ya está ordenada por _evaluate_population
        return self.population[0]

    def run(self):
        self._initialize_population()
        
        for gen in range(self.generations):
            self._evaluate_population() # Asegura que la población esté evaluada y ordenada

            best_current_gen = self._get_best_individual()
            if best_current_gen:
                self.best_individual_history.append(best_current_gen.fitness)
                self.avg_fitness_history.append(np.mean([ind.fitness for ind in self.population if ind.fitness != -np.inf]))
                # Opcional: peor
                worst_fitness = self.population[-1].fitness if self.population else -np.inf
                self.worst_individual_history.append(worst_fitness)

            print(f"Generación {gen+1}/{self.generations} - Mejor Fitness: {best_current_gen.fitness if best_current_gen else 'N/A'}")

            # 1. Selección
            parents = self.selection_strategy(self.population, num_parents=self.population_size) # O un número específico

            # 2. Cruza
            offspring_population = []
            # Asegurarse de tener un número par de padres si la cruza requiere parejas
            num_potential_offspring = len(parents) // 2 
            
            for i in range(num_potential_offspring):
                parent1 = parents[i*2]
                parent2 = parents[i*2 + 1]
                if random.random() < self.p_crossover:
                    child1_chromo, child2_chromo = self.crossover_strategy(parent1.chromosome, parent2.chromosome)
                    offspring_population.append(Individual(self.num_bits, chromosome=child1_chromo))
                    offspring_population.append(Individual(self.num_bits, chromosome=child2_chromo))
                else:
                    # Si no hay cruza, los padres pasan directamente (o copias)
                    offspring_population.append(Individual(self.num_bits, chromosome=list(parent1.chromosome)))
                    offspring_population.append(Individual(self.num_bits, chromosome=list(parent2.chromosome)))
            
            # 3. Mutación
            for individual in offspring_population:
                if random.random() < self.p_mutation_individual:
                    self.mutation_strategy(individual, self.p_mutation_gene)
                    individual._decode_and_evaluate() # Re-evaluar si mutó

            # 4. Reemplazo / Poda (Elitismo implícito en algunas estrategias)
            # Combina población actual con la descendencia
            combined_population = self.population + offspring_population
            self.population = self.pruning_strategy(combined_population, 
                                                     target_size=self.population_size,
                                                     maximization=self.maximization,
                                                     max_pop_allowed=self.max_population_size)
            
            # Forzar reevaluación y ordenamiento después de poda
            self._evaluate_population()


        # Resultados finales
        final_best = self._get_best_individual()
        print("\n--- Resultados Finales ---")
        if final_best:
            print(f"Mejor individuo: {final_best}")
            print(f"Cadena de bits: {''.join(map(str, final_best.chromosome))}")
            print(f"Valor x: {final_best.x_value:.4f}")
            print(f"Fitness f(x): {final_best.fitness:.4f}")
        
        # Devolver el historial para las gráficas y la tabla de mejores
        # La tabla de "mejores individuos" podría ser los N mejores de la última generación
        self.population.sort(key=lambda ind: ind.fitness, reverse=self.maximization)
        top_n_individuals = self.population[:min(10, len(self.population))] # Top 10 por ejemplo

        return self.best_individual_history, self.avg_fitness_history, self.worst_individual_history, top_n_individuals