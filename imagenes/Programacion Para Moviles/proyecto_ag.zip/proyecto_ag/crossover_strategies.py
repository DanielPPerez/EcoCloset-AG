# crossover_strategies.py
import random

def single_point_crossover(parent1_chromo, parent2_chromo):
    """Cruza de un solo punto."""
    size = len(parent1_chromo)
    if size <= 1: # No se puede cruzar si la longitud es 1 o menos
        return list(parent1_chromo), list(parent2_chromo)
    
    point = random.randint(1, size - 1) # Punto de cruce
    child1_chromo = parent1_chromo[:point] + parent2_chromo[point:]
    child2_chromo = parent2_chromo[:point] + parent1_chromo[point:]
    return child1_chromo, child2_chromo

def two_point_crossover(parent1_chromo, parent2_chromo):
    """Cruza de dos puntos."""
    size = len(parent1_chromo)
    if size <= 2: # Necesita al menos 3 genes para 2 puntos distintos
        return list(parent1_chromo), list(parent2_chromo)

    point1 = random.randint(1, size - 2)
    point2 = random.randint(point1 + 1, size - 1)
    
    child1_chromo = parent1_chromo[:point1] + parent2_chromo[point1:point2] + parent1_chromo[point2:]
    child2_chromo = parent2_chromo[:point1] + parent1_chromo[point1:point2] + parent2_chromo[point2:]
    return child1_chromo, child2_chromo
    
# Ejemplo de cruza de 3 puntos como en la imagen
def three_point_crossover(parent1_chromo, parent2_chromo):
    size = len(parent1_chromo)
    if size <= 3:
        return list(parent1_chromo), list(parent2_chromo)

    points = sorted(random.sample(range(1, size), 3)) # 3 puntos de cruce distintos
    
    p0, p1, p2 = points[0], points[1], points[2]

    # Child1: P1_seg1 + P2_seg2 + P1_seg3 + P2_seg4
    # Child2: P2_seg1 + P1_seg2 + P2_seg3 + P1_seg4
    c1 = parent1_chromo[:p0] + parent2_chromo[p0:p1] + parent1_chromo[p1:p2] + parent2_chromo[p2:]
    c2 = parent2_chromo[:p0] + parent1_chromo[p0:p1] + parent2_chromo[p1:p2] + parent1_chromo[p2:]
    return c1, c2

# Puedes añadir más (Uniform Crossover, etc.)
AVAILABLE_CROSSOVER_STRATEGIES = {
    "Un Punto": single_point_crossover,
    "Dos Puntos": two_point_crossover,
    "Tres Puntos (Imagen)": three_point_crossover,
}