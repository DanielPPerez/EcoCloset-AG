# utils.py
import numpy as np

def bits_to_int(bit_string):
    """Convierte una cadena de bits (lista o string) a entero."""
    return int("".join(map(str, bit_string)), 2)

def int_to_bits(value, num_bits):
    """Convierte un entero a una cadena de bits de longitud num_bits."""
    return [int(b) for b in bin(value)[2:].zfill(num_bits)]

def decode_chromosome(bit_string, x_min, x_max):
    """Decodifica un cromosoma (cadena de bits) a un valor real x."""
    num_bits = len(bit_string)
    max_int_val = 2**num_bits - 1
    int_val = bits_to_int(bit_string)
    # Mapeo lineal
    x = x_min + (int_val / max_int_val) * (x_max - x_min)
    return x

def calculate_actual_delta_x(x_min, x_max, num_bits):
    """Calcula el delta x real basado en el número de bits."""
    if num_bits <= 0:
        return 0
    return (x_max - x_min) / (2**num_bits - 1)