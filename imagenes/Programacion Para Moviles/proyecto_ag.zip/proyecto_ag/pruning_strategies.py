# pruning_strategies.py
import random

def elitism_replacement(combined_population, target_size, maximization=True, max_pop_allowed=None):
    """Reemplazo con elitismo. Simplemente toma los mejores 'target_size' individuos."""
    # Asegurar que la población combinada no exceda max_pop_allowed antes de ordenar, si se especifica
    if max_pop_allowed and len(combined_population) > max_pop_allowed:
        # Podría ser una poda aleatoria para reducir al máximo permitido antes de seleccionar los mejores
        # O simplemente truncar. Por ahora, se asume que max_pop_allowed es un límite suave
        # o que la selección de los mejores ya lo maneja.
        pass 

    combined_population.sort(key=lambda ind: ind.fitness, reverse=maximization)
    return combined_population[:target_size]

def generational_replacement(combined_population, target_size, maximization=True, max_pop_allowed=None):
    """
    Reemplazo generacional simple. Toma los 'target_size' mejores de la descendencia
    y la población original combinada.
    Similar a elitism_replacement si la descendencia y padres se combinan.
    Si 'combined_population' solo fuera la descendencia, y se quiere reemplazar toda la
    población anterior, entonces sería:
    offspring_population.sort(...)
    return offspring_population[:target_size]
    Pero el GA_core pasa la población combinada, así que es lo mismo que elitismo.
    """
    return elitism_replacement(combined_population, target_size, maximization, max_pop_allowed)


AVAILABLE_PRUNING_STRATEGIES = {
    "Elitismo": elitism_replacement,
    "Reemplazo Generacional (con elitismo)": generational_replacement,
}