# selection_strategies.py
import random

def tournament_selection(population, num_parents, tournament_size=3):
    """Selección por torneo."""
    selected_parents = []
    if not population: return []
    
    # Determinar si es maximización o minimización basado en el orden de la población
    # (asumiendo que la población está ordenada: mejor primero)
    is_maximization = True
    if len(population) > 1 and population[0].fitness < population[-1].fitness:
        is_maximization = False
        
    for _ in range(num_parents):
        tournament_contenders = random.sample(population, tournament_size)
        if is_maximization:
            winner = max(tournament_contenders, key=lambda ind: ind.fitness)
        else:
            winner = min(tournament_contenders, key=lambda ind: ind.fitness)
        selected_parents.append(winner)
    return selected_parents

def roulette_wheel_selection(population, num_parents):
    """Selección por Ruleta (asume maximización y fitness no negativo)."""
    # Requiere ajustes para minimización o fitness negativo (e.g., escalado)
    # Este es un ejemplo básico, podría necesitar más robustez.
    selected_parents = []
    if not population: return []

    total_fitness = sum(ind.fitness for ind in population if ind.fitness > 0) # Simple, ignora negativos
    if total_fitness == 0: # Todos con fitness 0 o negativo, seleccionar al azar
        return random.sample(population, min(num_parents, len(population)))

    for _ in range(num_parents):
        pick = random.uniform(0, total_fitness)
        current = 0
        for individual in population:
            if individual.fitness > 0: # Solo considera positivos para la ruleta simple
                current += individual.fitness
                if current >= pick:
                    selected_parents.append(individual)
                    break
        else: # Fallback si algo sale mal (ej. todos fitness 0)
             selected_parents.append(random.choice(population))
    return selected_parents

# Puedes añadir más estrategias aquí (Rank selection, etc.)
AVAILABLE_SELECTION_STRATEGIES = {
    "Torneo": tournament_selection,
    "Ruleta": roulette_wheel_selection,
}