# main_app.py
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

from config import FUNCTION_STRING, X_MIN, X_MAX, fitness_function
from ga_core import GeneticAlgorithm, Individual
from utils import calculate_actual_delta_x # Para calcular N_BITS o Delta_X real

# Importar estrategias (deberías tener estos archivos)
from selection_strategies import AVAILABLE_SELECTION_STRATEGIES
from crossover_strategies import AVAILABLE_CROSSOVER_STRATEGIES
from mutation_strategies import AVAILABLE_MUTATION_STRATEGIES
from pruning_strategies import AVAILABLE_PRUNING_STRATEGIES


class GeneticApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Algoritmo Genético Max/Min")
        self.root.geometry("1000x750")

        # --- Parámetros del AG ---
        self.param_frame = ttk.LabelFrame(root, text="Parámetros del AG")
        self.param_frame.pack(padx=10, pady=10, fill="x")

        self.entries = {}
        self.num_bits = tk.IntVar(value=8) # Valor inicial, podría calcularse
        self.actual_delta_x_var = tk.StringVar(value=f"{(X_MAX - X_MIN) / (2**self.num_bits.get() -1):.4f}")


        params_config = [
            ("Población Inicial:", "pop_size", 50),
            ("Población Máxima:", "max_pop_size", 100),
            ("PMI (Prob. Mutación Individuo):", "pmi", 0.1), # Ej: 0.1 = 10%
            ("PMG (Prob. Mutación Gen):", "pmg", 0.01),    # Ej: 0.01 = 1%
            ("Prob. Cruza (Emparejamiento):", "p_crossover", 0.7), # Ej: 0.7 = 70%
            ("Delta X (deseado, afecta #bits):", "delta_x", 0.1), # Para calcular N_BITS
            ("Cantidad de Generaciones:", "generations", 100),
        ]

        for i, (label_text, key, default_val) in enumerate(params_config):
            label = ttk.Label(self.param_frame, text=label_text)
            label.grid(row=i, column=0, padx=5, pady=2, sticky="w")
            entry_var = tk.DoubleVar(value=default_val)
            if key == "pop_size" or key == "max_pop_size" or key == "generations":
                entry_var = tk.IntVar(value=default_val)

            entry = ttk.Entry(self.param_frame, textvariable=entry_var, width=10)
            entry.grid(row=i, column=1, padx=5, pady=2, sticky="ew")
            self.entries[key] = entry_var
            if key == "delta_x": # Asociar cambio en Delta X a N_BITS
                entry_var.trace_add("write", self._update_num_bits_and_actual_delta)


        # --- Número de Bits y Delta X real (calculado) ---
        ttk.Label(self.param_frame, text="Número de Bits (calculado/fijo):").grid(row=len(params_config), column=0, padx=5, pady=2, sticky="w")
        self.num_bits_entry = ttk.Entry(self.param_frame, textvariable=self.num_bits, width=10, state="readonly") # O editable si se quiere fijar
        self.num_bits_entry.grid(row=len(params_config), column=1, padx=5, pady=2, sticky="ew")
        self.num_bits.trace_add("write", self._update_actual_delta_from_bits)


        ttk.Label(self.param_frame, text="Delta X (real, calculado):").grid(row=len(params_config)+1, column=0, padx=5, pady=2, sticky="w")
        self.actual_delta_x_label = ttk.Label(self.param_frame, textvariable=self.actual_delta_x_var)
        self.actual_delta_x_label.grid(row=len(params_config)+1, column=1, padx=5, pady=2, sticky="ew")


        # --- Modo: Maximización / Minimización ---
        self.mode_var = tk.StringVar(value="maximizar")
        ttk.Label(self.param_frame, text="Objetivo:").grid(row=len(params_config)+2, column=0, padx=5, pady=2, sticky="w")
        max_rb = ttk.Radiobutton(self.param_frame, text="Maximizar", variable=self.mode_var, value="maximizar")
        max_rb.grid(row=len(params_config)+2, column=1, sticky="w")
        min_rb = ttk.Radiobutton(self.param_frame, text="Minimizar", variable=self.mode_var, value="minimizar")
        min_rb.grid(row=len(params_config)+2, column=2, sticky="w")
        
        # Inicializar N_BITS y Delta X real
        self._update_num_bits_and_actual_delta()


        # --- Selección de Estrategias ---
        self.strategy_frame = ttk.LabelFrame(root, text="Estrategias del AG")
        self.strategy_frame.pack(padx=10, pady=5, fill="x")
        self.strategy_vars = {}

        strategies = [
            ("Selección:", "selection", AVAILABLE_SELECTION_STRATEGIES),
            ("Cruza:", "crossover", AVAILABLE_CROSSOVER_STRATEGIES),
            ("Mutación:", "mutation", AVAILABLE_MUTATION_STRATEGIES),
            ("Poda/Reemplazo:", "pruning", AVAILABLE_PRUNING_STRATEGIES),
        ]

        for i, (label_text, key, options_dict) in enumerate(strategies):
            ttk.Label(self.strategy_frame, text=label_text).grid(row=i, column=0, padx=5, pady=2, sticky="w")
            var = tk.StringVar(value=list(options_dict.keys())[0]) # Default to first option
            combo = ttk.Combobox(self.strategy_frame, textvariable=var, values=list(options_dict.keys()), state="readonly", width=30)
            combo.grid(row=i, column=1, padx=5, pady=2, sticky="ew")
            self.strategy_vars[key] = var

        # --- Botón de Inicio ---
        self.run_button = ttk.Button(root, text="Ejecutar Algoritmo Genético", command=self.run_ga)
        self.run_button.pack(padx=10, pady=10)

        # --- Visualización de la Fórmula ---
        self.formula_label = ttk.Label(root, text=f"Fórmula de Aptitud: {FUNCTION_STRING}", font=("Arial", 12, "bold"))
        self.formula_label.pack(pady=5)
        
        # --- Paneles para Gráficas y Tabla ---
        self.results_notebook = ttk.Notebook(root)
        self.results_notebook.pack(padx=10, pady=10, fill="both", expand=True)

        # Pestaña para Gráfica de Evolución
        self.evo_tab = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.evo_tab, text='Evolución Fitness')
        self.fig_evo, self.ax_evo = plt.subplots()
        self.canvas_evo = FigureCanvasTkAgg(self.fig_evo, master=self.evo_tab)
        self.canvas_widget_evo = self.canvas_evo.get_tk_widget()
        self.canvas_widget_evo.pack(fill=tk.BOTH, expand=True)

        # Pestaña para Gráfica de Función y Mejor Individuo
        self.func_tab = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.func_tab, text='Función y Mejor Solución')
        self.fig_func, self.ax_func = plt.subplots()
        self.canvas_func = FigureCanvasTkAgg(self.fig_func, master=self.func_tab)
        self.canvas_widget_func = self.canvas_func.get_tk_widget()
        self.canvas_widget_func.pack(fill=tk.BOTH, expand=True)
        self._plot_base_function() # Dibujar la función base al inicio

        # Pestaña para Tabla de Mejores Individuos
        self.table_tab = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.table_tab, text='Mejores Individuos')
        cols = ("Índice", "Cadena Bits", "Valor x", "f(x)")
        self.tree = ttk.Treeview(self.table_tab, columns=cols, show='headings')
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150, anchor='center')
        self.tree.pack(fill=tk.BOTH, expand=True)


    def _update_num_bits_and_actual_delta(self, *args):
        try:
            delta_x_deseado = self.entries["delta_x"].get()
            if delta_x_deseado <= 0:
                # self.num_bits.set(0) # o manejar error
                # self.actual_delta_x_var.set("Inválido")
                return # Evita cálculo con delta inválido

            num_intervalos = (X_MAX - X_MIN) / delta_x_deseado
            n_bits = int(np.ceil(np.log2(num_intervalos + 1))) # +1 para incluir el último punto
            if n_bits <=0: n_bits = 1 # Mínimo 1 bit
            
            # Como num_bits es un IntVar, al cambiarlo se llamará a _update_actual_delta_from_bits
            # Evitar bucle infinito si ambos se trazan mutuamente de forma directa.
            # La traza es solo en delta_x -> num_bits, y num_bits -> actual_delta_x_label
            if self.num_bits.get() != n_bits: # Solo actualiza si es diferente
                self.num_bits.set(n_bits)
            else: # Si n_bits no cambió, forza la actualización de actual_delta_x_var
                self._update_actual_delta_from_bits()

        except (tk.TclError, ValueError): # Puede ocurrir si el entry está vacío o no es número
            # self.num_bits.set(0)
            # self.actual_delta_x_var.set("N/A")
            pass # No hacer nada si el valor es temporalmente inválido

    def _update_actual_delta_from_bits(self, *args):
        try:
            n_bits = self.num_bits.get()
            if n_bits <= 0:
                self.actual_delta_x_var.set("N/A (bits <=0)")
                return
            
            actual_delta = calculate_actual_delta_x(X_MIN, X_MAX, n_bits)
            self.actual_delta_x_var.set(f"{actual_delta:.5f}")
        except (tk.TclError, ValueError):
            self.actual_delta_x_var.set("N/A")
            pass


    def _plot_base_function(self):
        self.ax_func.clear()
        x_vals = np.linspace(X_MIN, X_MAX, 500)
        y_vals = np.array([fitness_function(x) for x in x_vals])
        
        # Filtrar infinitos para graficar
        finite_mask = np.isfinite(y_vals)
        
        self.ax_func.plot(x_vals[finite_mask], y_vals[finite_mask], label=FUNCTION_STRING, color='blue')
        self.ax_func.set_title("Función de Aptitud y Mejor Solución Encontrada")
        self.ax_func.set_xlabel("x")
        self.ax_func.set_ylabel("f(x)")
        self.ax_func.legend()
        self.ax_func.grid(True)
        self.canvas_func.draw()


    def run_ga(self):
        try:
            # Obtener parámetros de la GUI
            pop_size = self.entries["pop_size"].get()
            max_pop_size = self.entries["max_pop_size"].get()
            pmi = self.entries["pmi"].get()
            pmg = self.entries["pmg"].get()
            p_crossover = self.entries["p_crossover"].get()
            # delta_x_des = self.entries["delta_x"].get() # Ya usado para calcular num_bits
            n_bits = self.num_bits.get()
            generations = self.entries["generations"].get()
            maximization = True if self.mode_var.get() == "maximizar" else False

            # Validaciones básicas
            if not (0 <= pmi <= 1 and 0 <= pmg <= 1 and 0 <= p_crossover <= 1):
                messagebox.showerror("Error", "Las probabilidades deben estar entre 0 y 1.")
                return
            if pop_size <= 0 or generations <= 0 or n_bits <= 0:
                messagebox.showerror("Error", "Población, generaciones y número de bits deben ser positivos.")
                return

            # Obtener estrategias seleccionadas
            sel_strat_name = self.strategy_vars["selection"].get()
            cro_strat_name = self.strategy_vars["crossover"].get()
            mut_strat_name = self.strategy_vars["mutation"].get()
            pru_strat_name = self.strategy_vars["pruning"].get()

            selection_func = AVAILABLE_SELECTION_STRATEGIES[sel_strat_name]
            crossover_func = AVAILABLE_CROSSOVER_STRATEGIES[cro_strat_name]
            mutation_func = AVAILABLE_MUTATION_STRATEGIES[mut_strat_name]
            pruning_func = AVAILABLE_PRUNING_STRATEGIES[pru_strat_name]
            
            # --- Confirmar que X_MIN, X_MAX y fitness_function son consistentes ---
            # (ya están importados de config.py)

            # Crear y ejecutar el AG
            ga = GeneticAlgorithm(
                population_size=pop_size,
                num_bits=n_bits,
                p_mutation_individual=pmi,
                p_mutation_gene=pmg,
                p_crossover=p_crossover,
                generations=generations,
                selection_strategy=selection_func,
                crossover_strategy=crossover_func,
                mutation_strategy=mutation_func,
                pruning_strategy=pruning_func,
                maximization=maximization,
                max_population_size=max_pop_size
            )
            
            best_hist, avg_hist, worst_hist, top_individuals = ga.run()

            # Actualizar gráficas y tabla
            self.update_evolution_graph(best_hist, avg_hist, worst_hist)
            self.update_function_graph_with_best(top_individuals[0] if top_individuals else None)
            self.update_results_table(top_individuals)

            messagebox.showinfo("Completado", "Algoritmo Genético finalizado.")

        except ValueError as e:
            messagebox.showerror("Error de Valor", f"Por favor, ingrese valores numéricos válidos.\n{e}")
        except Exception as e:
            messagebox.showerror("Error Inesperado", f"Ocurrió un error: {e}")
            import traceback
            traceback.print_exc()


    def update_evolution_graph(self, best_hist, avg_hist, worst_hist):
        self.ax_evo.clear()
        generations = range(1, len(best_hist) + 1)
        self.ax_evo.plot(generations, best_hist, label="Mejor Fitness", color='green')
        self.ax_evo.plot(generations, avg_hist, label="Fitness Promedio", color='blue')
        self.ax_evo.plot(generations, worst_hist, label="Peor Fitness", color='red', linestyle='--')
        self.ax_evo.set_title("Evolución del Fitness por Generación")
        self.ax_evo.set_xlabel("Generación")
        self.ax_evo.set_ylabel("Fitness")
        self.ax_evo.legend()
        self.ax_evo.grid(True)
        self.canvas_evo.draw()

    def update_function_graph_with_best(self, best_individual):
        self._plot_base_function() # Redibuja la función base
        if best_individual:
            op_char = "Máximo" if self.mode_var.get() == "maximizar" else "Mínimo"
            self.ax_func.plot(best_individual.x_value, best_individual.fitness, 'ro', markersize=10, 
                              label=f'{op_char} Encontrado\nx={best_individual.x_value:.3f}, f(x)={best_individual.fitness:.3f}')
            self.ax_func.legend() # Actualizar leyenda para incluir el punto
        self.canvas_func.draw()

    def update_results_table(self, individuals_list):
        # Limpiar tabla anterior
        for i in self.tree.get_children():
            self.tree.delete(i)
        
        # Llenar con nuevos datos
        for i, ind in enumerate(individuals_list):
            bits_str = "".join(map(str, ind.chromosome))
            self.tree.insert("", "end", values=(
                i + 1,  # Índice (1-based)
                bits_str,
                f"{ind.x_value:.4f}",
                f"{ind.fitness:.4f}"
            ))

if __name__ == "__main__":
    root = tk.Tk()
    app = GeneticApp(root)
    root.mainloop()