# config.py
import numpy as np

# --- Parámetros del Problema ---
# Función de Aptitud (Fitness Function)
# Vista en el pizarrón: f(x) = ln(|x * cos(x)|)
def fitness_function(x):
    """
    Calcula la aptitud de un valor x.
    Maneja el caso donde x*cos(x) es 0 o muy cercano, donde ln() no estaría definido o sería -inf.
    Usamos un valor pequeño para evitar errores con ln(0).
    """
    val = x * np.cos(x)
    if np.abs(val) < 1e-9: # Evitar ln(0)
        return -np.inf # O un valor negativo muy grande
    return np.log(np.abs(val))

FUNCTION_STRING = "f(x) = ln(|x * cos(x)|)" # Para mostrar en la GUI
X_MIN = -2.0
X_MAX = 16.0
# Delta X deseado (aproximado, se ajustará según el número de bits)
# DELTA_X_DESIRED = 0.1 # Lo tomará el usuario

# --- Cálculo del Número de Bits ---
# Basado en las imágenes: #puntos = 181 -> 2^L >= 181. L=8 (2^8 = 256)
# Δx' = (16 - (-2)) / (2^8 - 1) = 18 / 255 = ~0.0705
# Esta lógica se podría mover a ga_core si Delta_X es un input directo que determina los bits
# Por ahora, asumamos que el número de bits se fija o se calcula a partir de un Delta_X deseado.

# Si el usuario da Delta X, calculamos N_BITS
# num_intervalos = (X_MAX - X_MIN) / DELTA_X_DESIRED
# N_BITS = int(np.ceil(np.log2(num_intervalos + 1)))
# Esta lógica irá en la GUI o en ga_core al iniciar

# Si fijamos N_BITS (ej. basado en la imagen del pizarrón #bits = 8)
# N_BITS = 8
# ACTUAL_DELTA_X = (X_MAX - X_MIN) / (2**N_BITS - 1)
# print(f"Con {N_BITS} bits, el Delta X real es: {ACTUAL_DELTA_X_REAL}")