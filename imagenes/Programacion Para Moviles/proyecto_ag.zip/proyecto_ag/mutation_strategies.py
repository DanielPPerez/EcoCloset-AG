# mutation_strategies.py
import random

def bit_flip_mutation(individual, p_mutation_gene):
    """Mutación por inversión de bit."""
    for i in range(len(individual.chromosome)):
        if random.random() < p_mutation_gene:
            individual.chromosome[i] = 1 - individual.chromosome[i] # Invierte el bit
    # La re-evaluación del fitness se hará en el bucle principal del AG si es necesario

AVAILABLE_MUTATION_STRATEGIES = {
    "Inversión de Bit": bit_flip_mutation,
}